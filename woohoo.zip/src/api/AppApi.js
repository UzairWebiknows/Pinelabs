import React from 'react'

const AppApi = () => {
  return (
    <div>AppApi</div>
  )
}

export default AppApi