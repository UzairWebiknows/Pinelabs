const appService = {}

const UpdateAppService = (a)=>{    
    return a*2;
}
appService.UpdateAppService = UpdateAppService

export default appService