import React from 'react'
const Home = () => {
  return (
<div>
  Home Screen
</div>

  )
}

export default Home