
const Cart = () => {
  return (
    <div></div>
  )
}

export default Cart